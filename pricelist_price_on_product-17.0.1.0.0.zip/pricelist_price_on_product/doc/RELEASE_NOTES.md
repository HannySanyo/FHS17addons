## Module <pricelist_price_on_product>

#### 06.04.2024
#### Version 17.0.1.0.0
#### ADD

- Initial Commit For Pricelist Price on Product
